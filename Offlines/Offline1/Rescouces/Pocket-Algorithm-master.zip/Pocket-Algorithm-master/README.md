# Pocket-Algorithm
Implementing Pocket Algorithm Using Jupyter Notebook


- Pocket Algorithm is similar to the perceptron algorithm its just the advanced version of the perceptron. Perceptron is jsut for the linearly classifying data, where Pocket algorithm is used when a data is not linearly sepearable and you want to sepreate data with the minimal error.
-you can implement the Pocket algorithm  using your own generated data. Your data doesn't need to be linearly separable, it can actually be any type of data.
-Implemented this method using numpy constructs and used the visualization techniques. 
-I have used Half Moon data set from the ML-SciKit book. And 1000 iteration to compare the best in sample error it can be any number.
-for More specification I have desplayed each iteration and and error rate calculated during that iteration.
